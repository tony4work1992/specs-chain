Dưới đây là **Business Requirement Document (BRD)** được mở rộng từ nội dung bạn cung cấp, **không thêm yêu cầu mới**, chỉ chuẩn hóa và làm rõ scope + business logic.

---

# **BUSINESS REQUIREMENT DOCUMENT (BRD)**

## **Feature: Sales Dashboard (Revenue Dashboard & Reporting)**

---

## **1. Purpose**

The purpose of the **Sales Dashboard** is to provide internal stakeholders with a centralized, visualized, and actionable overview of sales performance, financial health, and customer-related metrics.

The dashboard enables decision-makers to:

* Monitor business performance in real time or across selected time ranges
* Identify trends and performance changes compared to previous periods
* Analyze revenue distribution and conversion effectiveness
* Review recent transactional activities

---

## **2. Scope Definition**

### **2.1. In Scope**

The feature includes:

* Display of sales-related metrics and KPIs:

  * Total Revenue
  * Total Orders
  * Average Order Value (AOV)
  * Conversion Rate
  * Active Customers
  * Refund Rate

* Time-based data filtering using predefined and custom date ranges

* Visualization of analytical data through charts:

  * Revenue trends over time
  * Revenue distribution by product category
  * Comparison of traffic sources vs. conversions

* Display of detailed operational data:

  * Top-performing products
  * Recent transactions

* Trend comparison of KPIs against a previous period

* UI/UX requirements:

  * Modern, enterprise-level interface
  * Clean layout with high information density
  * Visual indicators (colors, icons, charts)
  * Loading states for data rendering

---

### **2.2. Out of Scope**

The following are not included in this feature:

* Data modification or transactional operations (e.g., creating or updating orders)
* Configuration of business rules or KPI calculation logic
* External system integrations setup
* User management or access control configuration
* Exporting reports (e.g., CSV, PDF)
* Drill-down navigation to detailed pages outside the dashboard

---

## **3. Stakeholders**

* **Primary Stakeholders:**

  * C-Level Executives (CEO, COO, CFO)
  * Sales / E-commerce Managers
  * Marketing Managers
  * Customer Success / Support Managers

* **Secondary Stakeholders:**

  * Product Managers
  * Business Analysts

---

## **4. Business Objectives**

* Provide a single source of truth for sales and revenue insights
* Enable faster decision-making through visualized data
* Improve visibility into performance trends and anomalies
* Support optimization of sales and marketing strategies

---

## **5. Functional Overview**

The Sales Dashboard is structured into four main sections:

---

### **5.1. Header & Global Controls**

* Display dashboard title and description

* Allow users to select a global date range:

  * Today
  * Last 7 days
  * Last 30 days
  * This year
  * Custom range

* All data on the dashboard must be updated according to the selected date range

---

### **5.2. KPI Metrics Section**

The system displays six KPI cards, each including:

* Metric name
* Current value
* Visual icon
* Trend indicator compared to the previous period

KPI definitions:

* Total Revenue
* Total Orders
* Average Order Value (AOV)
* Conversion Rate
* Active Customers
* Refund Rate

Trend indicators:

* Positive trend → displayed in green
* Negative trend → displayed in red

---

### **5.3. Analytical Charts Section**

#### **Revenue Overview**

* Displays revenue trends over time
* Supports time-based granularity (e.g., daily or monthly)
* Provides detailed data on hover (tooltip)

---

#### **Sales by Category**

* Displays distribution of revenue across product categories
* Categories include predefined groups (e.g., Electronics, Furniture, Clothing)
* Includes legend for category identification

---

#### **Traffic Sources & Conversions**

* Displays comparison between traffic (sessions) and sales
* Segmented by traffic sources:

  * Organic
  * Direct
  * Social
  * Ads

---

### **5.4. Detailed Data Section**

#### **Top Products**

* Displays top 5–10 products by revenue
* Includes:

  * Product name
  * Total revenue
  * Quantity sold
  * Relative comparison via progress bar against the top product

---

#### **Recent Transactions**

* Displays a list of the most recent transactions
* Includes:

  * Transaction ID
  * Customer name
  * Timestamp
  * Amount
  * Status:

    * Success
    * Processing
    * Failed

---

## **6. Business Rules**

* All metrics and data must reflect the selected date range
* Trend comparison must be calculated against the immediately preceding equivalent time period
* Refund Rate is expected to remain low; increasing trends must be highlighted negatively
* Data must be presented in appropriate formats:

  * Currency for revenue
  * Integer for counts
  * Percentage for rates

---

## **7. Non-Functional Requirements**

* **Performance:**

  * Dashboard must load efficiently despite multiple charts
  * Support smooth loading states (e.g., skeleton screens)

* **Usability:**

  * Clear visual hierarchy and readable layout
  * Minimal scrolling required

* **Visual Design:**

  * Consistent color usage for trends and statuses
  * Enterprise-grade UI appearance

---

## **8. Assumptions**

* Data sources for sales, traffic, and transactions are already available and reliable
* KPI calculation logic is predefined and consistent across the system
* Users have appropriate permissions to access dashboard data

---

## **9. Constraints**

* The dashboard is read-only
* The feature depends on the availability and performance of backend data services

---

Nếu bạn muốn bước tiếp theo, tôi có thể giúp bạn transform BRD này thành:

* **FRD (chi tiết behavior từng component + edge cases)**
* **UI Spec (mapping UI item → API)**
* **API contract + sample data structure (chuẩn AIPD)**
* **Checklist / Test cases auto-generate pipeline**

👉 Với case này, đi tiếp FRD là hợp lý nhất.
