CHECKLIST JSON SCHEMA
```
{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "Checklist Item Schema",
    "type": "object",
    "required": [
        "code",
        "type",
        "item",
        "description"
    ],
    "properties": {
        "code": {
            "type": "string",
            "pattern": "^CHE-\\d{5}$",
            "description": "Mã định danh duy nhất cho checklist item (VD: CHE-00001)"
        },
        "type": {
            "type": "string",
            "enum": [
                "Scope",
                "Impact"
            ],
            "description": "Loại kiểm tra"
        },
        "item": {
            "type": "string",
            "description": "Tên hạng mục hoặc mã Scope liên kết"
        },
        "description": {
            "type": "string",
            "description": "Mô tả chi tiết nội dung cần kiểm tra"
        }
    }
}
```

SCOPE JSON SCHEMA
```
{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "Scope Item Schema",
    "type": "object",
    "required": [
        "code",
        "systemName",
        "componentName",
        "elementName",
        "description"
    ],
    "properties": {
        "code": {
            "type": "string",
            "pattern": "^SCO-\\d{5}$",
            "description": "Mã định danh duy nhất cho Scope (VD: SCO-00001)"
        },
        "systemName": {
            "type": "string",
            "description": "Tên hệ thống áp dụng"
        },
        "componentName": {
            "type": "string",
            "enum": [
                "UI Item",
                "API",
                "UI Validation rules"
            ],
            "description": "Loại thành phần của hệ thống"
        },
        "elementName": {
            "type": "string",
            "description": "Tên phần tử cụ thể (UI, Endpoint, hoặc Quy tắc)"
        },
        "description": {
            "type": "string",
            "description": "Mô tả chức năng hoặc yêu cầu của Scope"
        }
    }
}
```

SCOPE JSON SCHEMA
```
{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "Impact Item Schema",
    "type": "object",
    "required": [
        "code",
        "systemName",
        "componentName",
        "elementName",
        "description"
    ],
    "properties": {
        "code": {
            "type": "string",
            "pattern": "^IMP-\\d{5}$",
            "description": "Mã định danh duy nhất cho Scope (VD: SCO-00001)"
        },
        "systemName": {
            "type": "string",
            "description": "Tên hệ thống áp dụng"
        },
        "componentName": {
            "type": "string",
            "enum": [
                "UI Item",
                "API",
                "UI Validation rules"
            ],
            "description": "Loại thành phần của hệ thống"
        },
        "elementName": {
            "type": "string",
            "description": "Tên phần tử cụ thể (UI, Endpoint, hoặc Quy tắc)"
        },
        "description": {
            "type": "string",
            "description": "Mô tả chức năng hoặc yêu cầu của Scope"
        }
    }
}
```

TEST CASE JSON SCHEMA
```
{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "Test Case Schema",
    "type": "object",
    "required": [
        "testcase_id",
        "group",
        "suite",
        "code",
        "tc_description",
        "priority",
        "complexity",
        "test_type",
        "core_custom",
        "version"
    ],
    "properties": {
        "testcase_id": {
            "type": "string",
            "format": "uuid",
            "description": "ID duy nhất của test case (định dạng UUID)"
        },
        "group": {
            "type": "string",
            "description": "Nhóm chức năng lớn (VD: Artifact Management)"
        },
        "suite": {
            "type": "string",
            "description": "Bộ test case cụ thể (VD: Artifact List, Filters, Create Artifact...)"
        },
        "code": {
            "type": "string",
            "pattern": "^CAS-\\d{5}$",
            "description": "Mã định danh Test Case (VD: CAS-00001)"
        },
        "pre_condition": {
            "type": "string",
            "description": "Điều kiện tiên quyết để thực hiện test case"
        },
        "tc_description": {
            "type": "string",
            "description": "Mô tả mục tiêu kiểm thử"
        },
        "ticket_code": {
            "type": "string",
            "pattern": "^JIRA-\\d+",
            "description": "Mã ticket liên kết trên JIRA"
        },
        "priority": {
            "type": "string",
            "enum": [
                "High",
                "Medium",
                "Low"
            ],
            "description": "Mức độ ưu tiên"
        },
        "complexity": {
            "type": "string",
            "enum": [
                "High",
                "Medium",
                "Low"
            ],
            "description": "Mức độ phức tạp của test case"
        },
        "test_type": {
            "type": "string",
            "enum": [
                "Functional",
                "Regression",
                "Smoke"
            ],
            "description": "Loại kiểm thử"
        },
        "core_custom": {
            "type": "string",
            "enum": [
                "Core",
                "Custom"
            ],
            "description": "Phân loại tính năng lõi hoặc tùy chỉnh"
        },
        "note": {
            "type": "string",
            "description": "Ghi chú bổ sung"
        },
        "reason": {
            "type": "string",
            "description": "Lý do tạo test case (VD: New feature, Bug fix)"
        },
        "version": {
            "type": "string",
            "pattern": "^\\d+\\.\\d+$",
            "description": "Phiên bản của test case"
        },
        "history": {
            "type": "string",
            "description": "Lịch sử cập nhật hoặc người tạo"
        }
    }
}
```

TEST STEP JSON SCHEMA
```
{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "Test Steps Schema",
    "type": "object",
    "description": "Cấu trúc lưu trữ các bước thực hiện test, phân cấp theo Test Specification (TES) và Test Case (CAS)",
    "additionalProperties": {
        "type": "object",
        "patternProperties": {
            "^CAS-\\d{5}$": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": [
                        "id",
                        "stepNumber",
                        "description",
                        "expectedResults"
                    ],
                    "properties": {
                        "id": {
                            "type": "string",
                            "format": "uuid",
                            "description": "ID duy nhất của bước thực hiện"
                        },
                        "stepNumber": {
                            "type": "string",
                            "pattern": "^STE-\\d{5}$",
                            "description": "Mã số bước (VD: STE-00001)"
                        },
                        "description": {
                            "type": "string",
                            "description": "Mô tả hành động của bước"
                        },
                        "expectedResults": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "required": [
                                    "id",
                                    "description"
                                ],
                                "properties": {
                                    "id": {
                                        "type": "integer",
                                        "description": "STT của kết quả mong đợi"
                                    },
                                    "description": {
                                        "type": "string",
                                        "description": "Mô tả kết quả mong đợi"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    "propertyNames": {
        "pattern": "^TES-\\d{6}$"
    }
}
```