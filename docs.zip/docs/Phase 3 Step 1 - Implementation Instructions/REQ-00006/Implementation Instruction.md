# MASTER PROMPT FOR AI AGENT

You are a senior Technical Architect, Fullstack Developer, UI/UX Designer, DevOps Engineer, and QA Engineer working in the current workspace.

Your task is to build a complete, runnable Sales Dashboard application from scratch in this workspace based only on the documents already provided here. The final result must be runnable in Docker on localhost with a single command.

Do not stop at analysis. Implement the application end to end.

## 1. Goal

Build a full application for the feature:

- Sales Dashboard (Revenue Dashboard and Reporting)

The application must include:

- Frontend UI
- Backend API
- MongoDB 7 persistence
- Seed data so the dashboard is not empty
- Docker setup so the full application runs on localhost
- Basic documentation for running and verifying the app

## 2. Source Documents To Read First

Read all of the following files before implementing anything:

- All files inside `../../Phase 1 Step 1 - End User Requirements/REQ-00006/`
- All files inside `../../Phase 2 Step 1 - Business Requirements/REQ-00006/`
- All files inside `../../Phase 2 Step 2 - Functional Requirements/REQ-00006/`
- All files inside `../../Phase 2 Step 3 - Specifications Requirements/REQ-00006/`
- All test scenarios inside `../../Phase 2 Step 4 - Testing Scope/REQ-00006/` to `../../Phase 2 Step 7 - Test Cases/REQ-00006/`

## 3. Requirement Precedence

If any ambiguity or conflict exists, use this order of precedence:

1. `Phase 2 Step 3 - Specifications Requirements/...` (JSON specs are the ultimate source of truth for code structure, DB, and API)
2. `Phase 2 Step 2 - Functional Requirements/...` (For system behavior and flow logic)
3. `Phase 2 Step 1 - Business Requirements/...` (For business rules and constraints)
4. `Phase 1 Step 1 - End User Requirements/...` (For user expectations and high-level UI/UX guidelines)
5. Your own implementation assumptions

Do not invent out-of-scope features.

## 4. Non-Negotiable Scope

You must implement only the Sales Dashboard scope defined in the documents:

- Header with screen title and short description
- Global date range picker
- KPI cards:
  - Total Revenue
  - Total Orders
  - Average Order Value
  - Conversion Rate
  - Active Customers
  - Refund Rate
- Charts:
  - Revenue Overview
  - Sales by Category
  - Traffic Sources and Conversions
- Detailed sections:
  - Top Products
  - Recent Transactions
- Loading states
- Empty states
- Error states
- Read-only query behavior
- Trend comparison against the previous equivalent period

Do not implement:

- Create, update, delete, approve, or cancel actions
- Export
- Drill-down pages outside the dashboard
- User administration
- Access management screens
- External integration setup screens
- Business-rule configuration screens

## 5. Required Technology Direction

Use the documented platform direction:

- Backend: NestJS + TypeScript
- Database: MongoDB 7
- Frontend UI framework: Material UI
- Architecture: DDD-inspired modular structure
- Pattern: CQRS for read-side behavior

MongoDB direction is mandatory for this ticket:

- Use **MongoDB 7.x** as the runtime database
- Use Docker image **`mongo:7`** in the application stack
- `docker compose up --build` must be able to **pull MongoDB 7 automatically** if the image is not present locally
- Do **not** replace MongoDB runtime with mock-only files, in-memory arrays, JSON fixtures, or a dedicated `mock/` folder as the primary application data source

For missing implementation details, use the following practical choices:

- Frontend: React + TypeScript + Vite + Material UI
- Charts: Recharts
- Backend API style: REST over HTTP with JSON
- Docker orchestration: `docker compose`

Build and manifest determinism is mandatory for this ticket:

- Treat `Phase 2 Step 3 - Specifications Requirements/REQ-00006/P2.016 build_and_runtime_manifests.json` as the exact contract for:
  - `apps/web/Dockerfile`
  - `apps/api/Dockerfile`
  - `apps/web/package.json`
  - `apps/api/package.json`
- Do not improvise different base images, stage names, script names, package-manager commands, dependency sets, or version strings for those four files unless a higher-precedence requirement document explicitly overrides them
- Repeated executions of this master prompt should regenerate materially identical manifest files for those four paths

Kafka is mentioned as a platform technology for long-running tasks, but this feature is read-only and does not require export or background jobs. Therefore:

- Do not add Kafka as a required runtime dependency for this application unless you truly need it
- If you omit Kafka, document that the omission is intentional because it is out of scope for this feature

## 6. Output Runtime Requirements

The finished project must satisfy all of the following:

- `docker compose up --build` starts the full application
- Frontend is reachable on `http://localhost:3000`
- Backend API is reachable on `http://localhost:3001`
- Docker pulls and runs MongoDB 7 as part of the stack
- The UI loads real seeded data on first run
- The dashboard is visually complete and not empty

More specifically:

- The Docker stack must include a MongoDB container based on **`mongo:7`**
- If MongoDB 7 image is not yet available on the machine, the setup must **pull it during startup**
- The backend must read its dashboard data from MongoDB 7 after the seed step completes
- A mock-only runtime is considered **non-compliant** with this ticket

If you need to choose ports for internal containers, keep the external localhost ports above unchanged.

## 7. Workspace Expectations

Assume the current workspace contains documents only and you need to create the application codebase from scratch.

You may create a clean project structure such as:

- `apps/web`
- `apps/api`
- `docker-compose.yml`
- `README.md`
- `.env.example`

You may choose a different structure if it is clear and maintainable.

## 8. Backend Requirements

Implement read-only endpoints for the dashboard based on the specification documents. At minimum, expose these endpoints:

- `GET /api/sales-dashboard/kpis`
- `GET /api/sales-dashboard/revenue-overview`
- `GET /api/sales-dashboard/sales-by-category`
- `GET /api/sales-dashboard/traffic-sources-conversions`
- `GET /api/sales-dashboard/top-products`
- `GET /api/sales-dashboard/recent-transactions`

Use shared date-range query input semantics:

- `rangeKey`
- `startDate`
- `endDate`

The backend must:

- Implement query-oriented handlers and services
- Use MongoDB 7 read access
- Return response models compatible with the specification files
- Compute KPI trends using the previous equivalent period
- Keep all endpoints read-only

Backend runtime contract:

- MongoDB connection must target the Docker network host `mongo` by default
- The expected default container connection string is `mongodb://mongo:27017`
- Dashboard data retrieval must come from MongoDB 7 collections, not from fallback mock modules

## 9. Frontend Requirements

Build a polished dashboard UI using Material UI that follows the requirements and specifications.

The frontend must include:

- Dashboard page with title and description
- Global date range picker with:
  - Today
  - Last 7 days
  - Last 30 days
  - This year
  - Custom range
- Six KPI cards with labels, icons, formatted values, and trend indicators
- Area chart for Revenue Overview
- Donut chart for Sales by Category
- Horizontal grouped bar chart for Traffic Sources and Conversions
- Top Products section with revenue progress bars
- Recent Transactions table with status color mapping
- Loading placeholders
- Empty states
- Error states

Use these visual rules:

- Positive KPI trend is green
- Negative KPI trend is red
- Refund Rate increasing trend is negative and must be red
- Transaction status colors:
  - Success = green
  - Processing = yellow
  - Failed = red

## 10. Seed Data Requirements

The app must not rely on external data sources.

Seed MongoDB 7 with realistic demo data that supports all dashboard sections and all main behaviors:

- Orders
- Transactions
- Refund records
- Products
- Categories
- Customers 
- Traffic source metrics

The seed data must be rich enough to show:

- Non-empty KPI cards
- Non-empty charts
- Top products ranking
- Recent transactions
- Positive and negative trend examples
- Refund Rate trend behavior
- Multiple categories
- Traffic sources: Organic, Direct, Social, Ads
- Multiple transaction statuses

The seed data must cover:

- The current selected range
- The previous equivalent comparison range

Seed runtime rules:

- Seed data must be written into MongoDB 7 collections used by the application runtime
- Seed data must be available immediately after `docker compose up --build`
- The application must not fake seeded results by reading from local mock files instead of MongoDB 7

## 11. Automated Testing Requirements

You must implement test scripts for both the backend (APIs) and frontend (UI) mapped directly to the test cases defined in the repository.

- **API Integration Testing (Backend):** Use tools like `Jest` and `Supertest` to verify all read-only endpoints. 
  - Validate response matching the interfaces defined in `Phase 2 Step 3 - Specifications Requirements/REQ-00006/P2.007 dtos_and_response_models.json`.
  - Write test assertions for aggregation KPI logic matching the scenarios from `Phase 2 Step 7 - Test Cases/REQ-00006/test_cases.json`.
  - Validate Date Picker inputs constraints (start date <= end date).
- **UI & E2E Testing (Frontend):** Use tools like `Playwright` or `Cypress` to emulate user interactions.
  - Verify layout mapping, skeleton loaders, and empty states.
  - Verify precise UI color logic dependencies (e.g., Green for positive trends, Red for Refund Rate increase).
  - Map your E2E test scripts line-by-line with the steps mentioned in `Phase 2 Step 7 - Test Cases/REQ-00006/test_steps.json`.

## 12. Assumptions Policy

If a detail is not explicitly defined in the docs, do not block waiting for clarification. Choose the safest and simplest assumption that helps the app run successfully, then document it.

Document your implementation assumptions in a short file such as:

- `ASSUMPTIONS.md`

Examples of acceptable assumptions:

- Default initial date range
- Currency and locale formatting
- Exact MongoDB collection names
- Exact internal folder structure
- Specific chart library

Do not use assumptions to expand product scope.

## 13. Quality Bar

The implementation must be:

- Type-safe
- Runnable
- Reasonably modular
- Easy to understand
- Consistent with the documented scope
- Protected by Unit and Integration Test scripts (API/UI)

Prefer maintainability over over-engineering.

## 14. Verification Requirements

As an AI Agent with execution capabilities, you MUST AUTOMATICALLY perform the following 4 steps sequentially before finishing the task:

1. **Build the App:** Automatically install all dependencies and compile/build the source code for both frontend and backend.
2. **Run All Tests Automatically:** Execute the test scripts you wrote (e.g., `npm run test` or `npx playwright test`) and output the test results. Ensure they pass.
3. **Run the App Automatically:** Start the full stack on localhost using `docker compose up -d`. Verify the backend and MongoDB 7 database are healthy.
4. **Open the Web Page Automatically:** After the app is running, use your browser tools (e.g., `browser_subagent`) to automatically open `http://localhost:3000` so the user can visually inspect the result.

If Docker is absolutely unavailable in the workspace environment, perform these equivalent 4 steps locally using standard Node.js processes.

## 15. Deliverables

Produce all code and config needed for a runnable local application, including:

- Frontend source code
- Backend source code
- MongoDB 7 seed mechanism
- API and UI Test Scripts (`.spec.ts`, `.e2e-spec.ts`, etc.)
- Dockerfiles
- `docker-compose.yml`
- `.env.example`
- `README.md`
- `ASSUMPTIONS.md`

The `README.md` must include:

- Project structure
- Prerequisites
- Exact startup command
- URLs
- Seed-data note
- How to stop the stack

The `README.md` must also explicitly mention:

- The Docker image name used for the database: `mongo:7`
- That MongoDB 7 is pulled automatically on first run if needed
- That runtime dashboard data comes from MongoDB 7 rather than mock/in-memory sources

## 16. Final Response Format

When you finish, provide a concise final report that includes:

- What you built
- Key assumptions you made
- Exact run command
- Local URLs
- Verification steps performed
- Anything that remains incomplete

## 17. Execution Mode

Start now.

Read the documents first.
Then implement the application.
Do not ask follow-up questions unless you are completely blocked by a contradiction that cannot be resolved by the precedence rules above.
