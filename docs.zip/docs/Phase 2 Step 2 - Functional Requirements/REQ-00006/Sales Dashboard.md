# **FUNCTIONAL REQUIREMENT DOCUMENT (FRD)**

## **Feature: Sales Dashboard (Revenue Dashboard & Reporting)**

---

## **1. Document Purpose**

This document defines the functional requirements for the **Sales Dashboard** feature based on the approved Business Requirement Document (BRD).

The purpose of this feature is to provide internal users with a centralized dashboard for viewing sales-related KPIs, analytical charts, and recent transactional data within a selected time range.

This document describes:

* Functional scope
* User interactions
* Screen behavior
* Data presentation requirements
* Functional processing expectations
* System behavior relevant to the feature

---

## **2. Scope**

---

### **2.1. In Scope**

The Sales Dashboard feature includes the following functions:

1. Display a dashboard screen titled **Sales Dashboard**
2. Allow users to select a global date range
3. Refresh all dashboard data based on the selected date range
4. Display KPI cards for:

   * Total Revenue
   * Total Orders
   * Average Order Value (AOV)
   * Conversion Rate
   * Active Customers
   * Refund Rate
5. Display trend indicators for each KPI based on comparison with the previous equivalent period
6. Display analytical charts:

   * Revenue Overview
   * Sales by Category
   * Traffic Sources & Conversions
7. Display detailed data sections:

   * Top Products
   * Recent Transactions
8. Provide loading states while data is being retrieved and rendered

---

### **2.2. Out of Scope**

The following functions are excluded from this feature:

1. Creating, editing, canceling, or updating orders or transactions
2. Exporting dashboard data or reports
3. Configuring KPI calculation logic
4. Configuring chart definitions or business rules
5. User/role administration
6. Integration setup or external system configuration
7. Navigation to detailed drill-down screens outside this dashboard

---

## **3. Intended Users**

The feature is intended for internal users, including:

* C-Level Executives
* Sales / E-commerce Managers
* Marketing Managers
* Customer Success / Support Managers

---

## **4. Functional Context**

The system is implemented using:

* **NestJS** and **TypeScript**
* **MongoDB 7**
* **Kafka** for long-running processing tasks such as export and report aggregation
* **Domain Driven Design (DDD)**
* **MUI** for UI implementation
* **CQRS pattern**

For avoidance of doubt:

* The runtime database for this feature is **MongoDB 7.x**
* The intended Docker image is **`mongo:7`**
* The feature must not be implemented as a mock-only or in-memory dashboard runtime

For this feature, the Sales Dashboard is a **read-only query-based screen**. Based on the provided requirements, the feature focuses on retrieving and presenting data rather than modifying it.

---

## **5. Functional Requirements**

---

### **5.1. Dashboard Screen Initialization**

#### **FR-001: Display Sales Dashboard Screen**

The system shall display a screen named **Sales Dashboard**.

#### **FR-002: Display Screen Description**

The system shall display a short description below or near the screen title.

#### **FR-003: Load Dashboard Data on Screen Access**

When the user opens the Sales Dashboard screen, the system shall load dashboard data for the active date range.

#### **FR-004: Render Loading State During Data Retrieval**

While dashboard data is being retrieved, the system shall display loading placeholders appropriate for the dashboard layout.

---

### **5.2. Global Date Range Filter**

#### **FR-005: Display Global Date Range Picker**

The system shall provide a date range picker as a global control for the dashboard.

#### **FR-006: Support Predefined Date Range Options**

The date range picker shall support the following options:

* Today
* Last 7 days
* Last 30 days
* This year
* Custom range

#### **FR-007: Apply Selected Date Range to Entire Dashboard**

When the user changes the date range, the system shall refresh all dashboard sections using the selected date range.

#### **FR-008: Use the Selected Date Range Consistently**

The selected date range shall be applied consistently to:

* KPI cards
* Revenue Overview chart
* Sales by Category chart
* Traffic Sources & Conversions chart
* Top Products list
* Recent Transactions table

---

### **5.3. KPI Cards**

#### **FR-009: Display KPI Card Set**

The system shall display six KPI cards on the dashboard.

#### **FR-010: Display Required KPI Metrics**

The KPI cards shall represent the following metrics:

* Total Revenue
* Total Orders
* Average Order Value (AOV)
* Conversion Rate
* Active Customers
* Refund Rate

#### **FR-011: Display KPI Value**

Each KPI card shall display the current value for the selected date range.

#### **FR-012: Display KPI Label**

Each KPI card shall display the metric name.

#### **FR-013: Display KPI Icon**

Each KPI card shall display an icon associated with the metric.

#### **FR-014: Display KPI Trend**

Each KPI card shall display a trend value that compares the current period with the immediately previous equivalent period.

#### **FR-015: Display Trend Color by Positive/Negative Direction**

The trend indicator shall use:

* Green for positive trend
* Red for negative trend

#### **FR-016: Highlight Refund Rate Trend as Negative When Increasing**

For Refund Rate, an increasing trend shall be treated as negative and displayed in red.

#### **FR-017: Apply Data Formatting to KPI Values**

The system shall display KPI values using the appropriate format:

* Currency format for Total Revenue
* Integer format for Total Orders
* Percentage format for Conversion Rate
* Appropriate numeric representation for Average Order Value, Active Customers, and Refund Rate based on their data type

---

### **5.4. Revenue Overview Chart**

#### **FR-018: Display Revenue Overview Chart**

The system shall display a Revenue Overview chart in the dashboard.

#### **FR-019: Use Area Chart Presentation**

The Revenue Overview shall be displayed as an area chart.

#### **FR-020: Show Revenue Trend Over Time**

The chart shall present revenue trend data over time according to the selected date range.

#### **FR-021: Support Time-Based Data Points**

The chart shall display data points by time interval as defined in the dashboard dataset for the selected period.

#### **FR-022: Display Tooltip on Hover**

When the user hovers over a data point, the system shall display a tooltip containing the corresponding chart data.

---

### **5.5. Sales by Category Chart**

#### **FR-023: Display Sales by Category Chart**

The system shall display a Sales by Category chart.

#### **FR-024: Use Donut Chart Presentation**

The Sales by Category chart shall be displayed as a donut chart.

#### **FR-025: Display Revenue Distribution by Product Category**

The chart shall show the revenue distribution across product categories.

#### **FR-026: Display Category Legend**

The system shall display a legend to identify the categories represented in the chart.

#### **FR-027: Use Provided Category Dataset**

The chart shall render category values based on the available dataset for the selected date range.

---

### **5.6. Traffic Sources & Conversions Chart**

#### **FR-028: Display Traffic Sources & Conversions Chart**

The system shall display a Traffic Sources & Conversions chart.

#### **FR-029: Use Horizontal Bar Chart Presentation**

The chart shall be displayed as a horizontal grouped bar chart.

#### **FR-030: Compare Sessions and Sales**

The chart shall present a comparison between:

* Sessions
* Sales

#### **FR-031: Segment Data by Traffic Source**

The chart shall display data for traffic sources including:

* Organic
* Direct
* Social
* Ads

#### **FR-032: Use Selected Date Range for Traffic Comparison**

The chart data shall be filtered using the currently selected date range.

---

### **5.7. Top Products Section**

#### **FR-033: Display Top Products Section**

The system shall display a Top Products section.

#### **FR-034: Display Top 5 to 10 Products by Revenue**

The section shall display the top 5 to 10 products ranked by revenue for the selected date range.

#### **FR-035: Display Product Name**

Each product row shall display the product name.

#### **FR-036: Display Total Revenue per Product**

Each product row shall display total revenue.

#### **FR-037: Display Quantity Sold per Product**

Each product row shall display quantity sold.

#### **FR-038: Display Relative Revenue Progress**

Each product row shall display a progress bar representing the product’s revenue ratio compared with the top-ranked product.

---

### **5.8. Recent Transactions Section**

#### **FR-039: Display Recent Transactions Table**

The system shall display a Recent Transactions table.

#### **FR-040: Display Latest Transactions**

The table shall display the most recent transactions available within the selected date range.

#### **FR-041: Display Transaction ID**

Each row shall display the transaction ID.

#### **FR-042: Display Customer Name**

Each row shall display the customer name.

#### **FR-043: Display Transaction Timestamp**

Each row shall display the transaction time.

#### **FR-044: Display Transaction Amount**

Each row shall display the transaction amount.

#### **FR-045: Display Transaction Status**

Each row shall display the transaction status.

#### **FR-046: Display Status Color**

Transaction status shall be visually represented as:

* Success: Green
* Processing: Yellow
* Failed: Red

---

## **6. Functional Behavior**

---

### **6.1. Dashboard Data Refresh Behavior**

#### **FR-047: Refresh All Sections After Date Filter Change**

When the date range changes, the system shall reload all dashboard sections so that all displayed data remains aligned with the selected period.

#### **FR-048: Keep Screen Layout Stable During Reload**

When the dashboard reloads data, the system shall display loading placeholders without breaking the screen layout.

---

### **6.2. Trend Comparison Behavior**

#### **FR-049: Compare Against Previous Equivalent Period**

Trend values shall be calculated by comparing the selected period with the immediately previous equivalent period.

Examples:

* Today → compared with the previous day
* Last 7 days → compared with the previous 7-day period
* Last 30 days → compared with the previous 30-day period
* This year → compared with the previous equivalent year-to-date period
* Custom range → compared with the immediately previous equivalent-length date range

This section only clarifies the comparison basis already defined in the BRD and does not introduce new business logic.

---

### **6.3. Read-Only Query Behavior**

#### **FR-050: Provide Read-Only Dashboard Access**

The Sales Dashboard shall support data viewing only. No create, update, delete, or approval action shall be available from this feature.

#### **FR-051: Use Query-Oriented Processing**

Because the feature is read-only and follows CQRS, dashboard retrieval shall be handled as query behavior.

---

## **7. Data Presentation Requirements**

---

### **7.1. Formatting Rules**

#### **FR-052: Currency Formatting**

Revenue-related values shall be displayed in currency format.

#### **FR-053: Integer Formatting**

Count-based values shall be displayed in integer format where applicable.

#### **FR-054: Percentage Formatting**

Rate-based values shall be displayed in percentage format where applicable.

---

### **7.2. Visual Requirements**

#### **FR-055: Display a Clean and Informative Layout**

The dashboard shall present multiple data perspectives on one screen in a clean layout.

#### **FR-056: Use Clear Visual Distinction**

Charts, KPI trends, and transaction statuses shall use clear visual distinctions to improve readability.

#### **FR-057: Support Enterprise-Style UI**

The screen shall be implemented using the system UI framework and shall align with a modern, professional enterprise interface.

---

## **8. System Processing Considerations**

This section reflects the provided technical context only and does not add business requirements.

### **8.1. Backend Structure**

The system shall implement the feature within the existing backend architecture based on:

* NestJS
* TypeScript
* Domain Driven Design
* CQRS
* MongoDB 7

The read-side runtime source must be MongoDB 7 collections and not a mock-folder substitute.

### **8.2. Long-Running Task Processing**

Kafka is used in the platform for long-running tasks such as export and report aggregation.
Based on the current Sales Dashboard requirements, no export function is included in scope. Therefore, this feature is limited to dashboard data retrieval and presentation.

---

## **9. Assumptions**

1. Required sales, transaction, category, traffic, and customer data are available in the system
2. KPI values and chart data can be queried for the selected date range
3. Trend comparison data for the previous equivalent period is available
4. Users accessing this feature already have permission to view dashboard data

---

## **10. Constraints**

1. The feature is limited to the dashboard scope defined in the BRD
2. The feature is read-only
3. No additional workflow, approval, export, or drill-down behavior is included
4. Functional behavior must remain consistent with the original business requirements

---

## **11. Traceability to BRD**

This FRD expands the following BRD areas without adding new requirements:

* Dashboard purpose and scope
* Global date range control
* KPI card requirements
* Analytical chart requirements
* Top products and recent transactions requirements
* Read-only data presentation and trend comparison behavior

---

## **12. Summary**

The Sales Dashboard feature provides internal users with a read-only, centralized dashboard for viewing sales performance using KPIs, charts, and transactional data. All dashboard information is controlled by a global date range and must remain visually clear, trend-aware, and consistent across the screen.
